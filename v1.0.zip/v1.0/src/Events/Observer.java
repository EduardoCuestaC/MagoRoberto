package Events;

public interface Observer {
    public void updateOnEvent(Subject subject);
}
